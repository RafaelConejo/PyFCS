"""PyFCS test package."""
