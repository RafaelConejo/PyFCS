"""PyFCS common package."""
