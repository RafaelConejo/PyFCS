"""PyFCS data package."""
