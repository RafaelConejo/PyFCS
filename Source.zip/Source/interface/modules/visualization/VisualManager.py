import numpy as np
from matplotlib.colors import to_rgba
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import plotly.graph_objects as go
import plotly.express as px

# Project modules
from Source.geometry.Point import Point
from Source.interface.modules.common import UtilsTools


"""
Module summary
--------------
This module centralizes 3D visualization utilities for LAB color-space data and Voronoi-based
prototype volumes.

It provides:
    - Plotly-based 3D interactive rendering that can combine:
        * Representative centroids (LAB points)
        * Prototype polyhedra (Voronoi volumes) for Core / 0.5-cut / Support
        * Optional filtered points, displayed only when they truly fall inside each prototype volume
        * Optional custom/sample color markers for Color Evaluation
        * Optional closest-prototype highlighting
        * Legend handling to avoid duplicated legend entries
    - Matplotlib-based 3D rendering alternative for centroids and prototype volumes
    - Color Evaluation plots:
        * 3D LAB
        * a*b* projection
        * L*C* projection
        * LCh polar hue/chroma plot
        * Top-7 ranking bar plot
        * Membership-degree bar plot
        * Component-difference plot
    - Geometry helpers to:
        * Clip polygon faces to a bounding volume
        * Triangulate polygonal faces
        * Find display HEX colors from LAB coordinates
"""


class VisualManager:
    # Shared legend setting for plot traces.
    SHOW_LEGENDS = True

    # Geometry / Color Helpers

    @staticmethod
    def _fallback_model_hex(xyz, source_space):
        """Display a real site's color when HEX-keyed palettes are ambiguous.

        Different LAB representatives may quantize to the same 8-bit RGB/HEX.
        A palette dictionary indexed by HEX then represents only the last
        site, but the other site should not appear black in the 3D view.
        """
        try:
            if str(source_space).upper() == "RGB":
                return UtilsTools.rgb_to_hex(
                    UtilsTools.safe_rgb_tuple(np.asarray(xyz, dtype=float)))
            return UtilsTools.lab_to_hex(xyz)
        except (ValueError, TypeError, OverflowError):
            return "#000000"

    @staticmethod
    def clip_face_to_volume(vertices, volume_limits):
        """
        Clamp face vertices to the axis-aligned LAB bounding box defined by volume_limits.
        """
        if vertices is None:
            return np.empty((0, 3), dtype=float)

        processed_vertices = [
            vertex.get_double_point() if isinstance(vertex, Point) else vertex
            for vertex in vertices
        ]

        if not processed_vertices:
            return np.empty((0, 3), dtype=float)

        vertices_array = np.asarray(processed_vertices, dtype=float)

        lower_bounds = np.array(
            [volume_limits.comp1[0], volume_limits.comp2[0], volume_limits.comp3[0]],
            dtype=float,
        )
        upper_bounds = np.array(
            [volume_limits.comp1[1], volume_limits.comp2[1], volume_limits.comp3[1]],
            dtype=float,
        )

        # Clamp vertices for display; this does not close clipped polytopes.
        return np.clip(vertices_array, lower_bounds, upper_bounds)


    @staticmethod
    def _clip_display_polyhedron(faces, normal, offset, source_index, eps, merge_eps):
        """Clip only faces that cross the plane, retaining exact polygon order.

        Input polygons were created by the domain-box constructor or the
        original clipping algorithm and are already valid and deduplicated.
        Wholly inside faces need no re-clipping; wholly outside faces cannot
        contribute intersections. A conservative numerical guard leaves
        borderline cases to the original scalar segment intersection routine.
        This optimization is strictly for display geometry.
        """
        from Source.geometry.Voronoi import Voronoi, _PolyFace
        clipped_faces, cap_points = [], []
        # Supported model domains are bounded RGB/LAB. For very large custom
        # coordinates the caller retains the original clipping implementation.
        guard = 1e-10 + abs(offset) * 1e-14
        for face in faces:
            vertices = face.vertices
            values = vertices @ normal + offset
            # Bound the rounding error when the vector and scalar dot products
            # classify a vertex differently near the clipping tolerance.
            if values.min() >= -eps + guard:
                clipped_faces.append(face)
                continue
            if values.max() < -eps - guard:
                continue
            polygon, intersections = Voronoi._clip_polygon(vertices, normal, offset, eps, merge_eps)
            if intersections:
                cap_points.extend(intersections)
            if len(polygon) >= 3 and Voronoi._polygon_is_valid(polygon, merge_eps):
                clipped_faces.append(_PolyFace(face.normal, face.offset, polygon,
                                                face.source_index, face.is_domain_boundary))
        cap_points = Voronoi._unique_points(cap_points, merge_eps)
        if len(cap_points) >= 3:
            cap = Voronoi._order_points_on_plane(np.asarray(cap_points, dtype=float), normal)
            if Voronoi._polygon_is_valid(cap, merge_eps):
                clipped_faces.append(_PolyFace(np.asarray(normal, dtype=float), float(offset),
                                                cap, source_index, False))
        return clipped_faces

    @staticmethod
    def display_polygons_for_volume(volume, domain, include_domain_caps=True):
        """Clip a fuzzy polyhedron to the view domain, without changing its geometry.

        This is VISUAL geometry only: the real fuzzy halfspaces are clipped
        against the display domain, including the resulting closing faces.
        Those domain caps are essential to display closed Core / Voronoi /
        Support volumes.  They do not become membership boundaries: the fuzzy
        engine continues to ignore domain faces during radial membership.

        For diagnostic use, include_domain_caps=False yields open surfaces.
        """
        from Source.geometry.Voronoi import Voronoi

        eps = Voronoi.DEFAULT_EPS
        merge_eps = Voronoi.DEFAULT_MERGE_EPS
        faces = Voronoi._create_domain_faces(domain)
        fast_clip = all(float(domain.get_max(i)) - float(domain.get_min(i)) > merge_eps
                        and max(abs(float(domain.get_min(i))), abs(float(domain.get_max(i)))) <= 1000
                        for i in range(3))
        clip = VisualManager._clip_display_polyhedron if fast_clip else Voronoi._clip_polyhedron
        rep = volume.getRepresentative()
        representative = np.array([rep.x, rep.y, rep.z], dtype=float)
        vertices = Voronoi._collect_vertices(faces)
        for face in volume.getFaces():
            if face.isDomainBoundary():
                continue
            plane = face.getPlane()
            normal = np.array([plane.A, plane.B, plane.C], dtype=float)
            offset = float(plane.D)
            length = float(np.linalg.norm(normal))
            if length <= eps:
                continue
            # All clip planes must point towards the representative.
            if float(np.dot(normal, representative) + offset) < 0:
                normal = -normal
                offset = -offset
            normal /= length
            offset /= length
            if len(vertices) == 0:
                return []
            if np.min(vertices @ normal + offset) >= -eps:
                continue
            faces = clip(faces, normal, offset, face.getSourceIndex(), eps, merge_eps)
            if not faces:
                return []
            # The vertex set is unchanged when a plane does not cut the cell.
            vertices = Voronoi._collect_vertices(faces)
        return [np.asarray(face.vertices, dtype=float)
                for face in faces
                if face.vertices is not None and len(face.vertices) >= 3
                and (include_domain_caps or not face.is_domain_boundary)]

    @staticmethod
    def _display_geometry_key(prototype, domain):
        volume = prototype.voronoi_volume
        limits = (tuple(domain.comp1), tuple(domain.comp2), tuple(domain.comp3))
        rep = volume.getRepresentative()
        planes = tuple((float(f.getPlane().A), float(f.getPlane().B),
                        float(f.getPlane().C), float(f.getPlane().D),
                        bool(f.isDomainBoundary()), f.getSourceIndex())
                       for f in volume.getFaces())
        return (id(volume), limits, (rep.x, rep.y, rep.z), planes)

    @staticmethod
    def _cached_display_polygons(prototype, domain):
        """Share clipped surfaces between backends; invalidate after plane edits."""
        key = VisualManager._display_geometry_key(prototype, domain)
        cached = getattr(prototype, "_cached_visible_fuzzy_surfaces", None)
        if cached is not None and cached[0] == key:
            return cached[1]
        polygons = VisualManager.display_polygons_for_volume(
            prototype.voronoi_volume, domain, include_domain_caps=True)
        prototype._cached_visible_fuzzy_surfaces = (key, polygons)
        return polygons

    @staticmethod
    def has_cached_display_polygons(prototype, domain):
        cached = getattr(prototype, "_cached_visible_fuzzy_surfaces", None)
        return (cached is not None and
                cached[0] == VisualManager._display_geometry_key(prototype, domain))

    @staticmethod
    def has_cached_projected_display_faces(prototype, domain, source_space, display_space):
        cached = getattr(prototype, "_cached_visible_fuzzy_surfaces", None)
        projected = getattr(prototype, "_cached_projected_fuzzy_surfaces", None)
        return bool(cached is not None and projected is not None
                    and projected[0] is cached[1]
                    and projected[1] == str(source_space).upper()
                    and projected[2] == str(display_space).upper()
                    and cached[0] == VisualManager._display_geometry_key(prototype, domain))

    @staticmethod
    def _cached_projected_display_faces(prototype, domain, source_space,
                                       display_space):
        """Return view-space polygons in plotting axis order (y,z,x).

        Avoid repeated LAB/RGB conversions on every Matplotlib redraw, and
        share projections with the optional Plotly Interactive View.
        """
        polygons = VisualManager._cached_display_polygons(prototype, domain)
        source_space = str(source_space).upper()
        display_space = str(display_space).upper()
        old = getattr(prototype, "_cached_projected_fuzzy_surfaces", None)
        if (old is not None and old[0] is polygons
                and old[1] == source_space and old[2] == display_space):
            return old[3]
        if polygons:
            lengths = [len(polygon) for polygon in polygons]
            combined = np.concatenate(polygons, axis=0)
            converted = VisualManager.reproject_points(
                combined, source_space, display_space)[:, [1, 2, 0]]
            stops = np.cumsum(lengths)[:-1]
            result = np.split(converted, stops)
        else:
            result = []
        prototype._cached_projected_fuzzy_surfaces = (
            polygons, source_space, display_space, result)
        return result


    @staticmethod
    def _cached_plotly_display_mesh(prototype, domain, source_space,
                                    display_space):
        """Triangulate each visible polygon once, without duplicating triangles' vertices.

        Keep separate vertices for separate faces. Apart from saving work and
        reducing the serialized Mesh3d arrays, this preserves the per-face
        appearance (no vertex sharing between neighbouring faces).
        """
        polygons = VisualManager._cached_projected_display_faces(
            prototype, domain, source_space, display_space)
        previous = getattr(prototype, "_cached_plotly_visible_mesh", None)
        if previous is not None and previous[0] is polygons:
            return previous[1]

        vertices = []
        i_indices = []
        j_indices = []
        k_indices = []
        for polygon in polygons:
            n = len(polygon)
            if n < 3:
                continue
            first = len(vertices)
            vertices.extend(polygon)
            for corner in range(1, n - 1):
                i_indices.append(first)
                j_indices.append(first + corner)
                k_indices.append(first + corner + 1)

        if not i_indices:
            mesh = None
        else:
            mesh = (np.asarray(vertices, dtype=float),
                    i_indices, j_indices, k_indices)
        prototype._cached_plotly_visible_mesh = (polygons, mesh)
        return mesh


    @staticmethod
    def _lab_key(lab):
        """
        Convert LAB into a stable rounded key.
        """
        return tuple(np.round(np.asarray(lab, dtype=float).reshape(-1)[:3], 6))


    @staticmethod
    def _find_hex_for_lab(lab, hex_color, default="#000000"):
        """
        Find the HEX color associated with a LAB value.

        hex_color is expected as:
            {
                "#rrggbb": lab
            }
        """
        if not isinstance(hex_color, dict):
            return default

        target_key = VisualManager._lab_key(lab)

        for hex_value, lab_value in hex_color.items():
            try:
                if VisualManager._lab_key(lab_value) == target_key:
                    return hex_value
            except Exception:
                continue

        return default


    @staticmethod
    def _triangulate_face(vertices):
        """
        Convert a polygon face with N vertices into triangles.
        """
        triangles = []

        for i in range(1, len(vertices) - 1):
            triangles.append([vertices[0], vertices[i], vertices[i + 1]])

        return triangles


    @staticmethod
    def _safe_lab(lab):
        """
        Convert input LAB-like value to a 3-component numpy array.
        """
        if lab is None:
            return None

        arr = np.asarray(lab, dtype=float).reshape(-1)

        if arr.shape[0] < 3:
            return None

        return arr[:3]


    @staticmethod
    def _lab_to_lch(lab):
        """
        Convert CIELAB to CIELCh(ab).

        Returns
        -------
        tuple
            (L*, C*, h°)
        """
        lab = VisualManager._safe_lab(lab)

        if lab is None:
            return None

        L, a, b = lab
        C = float(np.sqrt(a ** 2 + b ** 2))
        h = float(np.degrees(np.arctan2(b, a)) % 360.0)

        return float(L), C, h


    @staticmethod
    def _format_metric_value(value, metric_name="CIEDE2000"):
        """
        Format ranking/metric values for hover labels and bar text.
        """
        try:
            value = float(value)
        except Exception:
            return "-"

        metric_name = str(metric_name)

        if metric_name in ("|ΔR|", "|ΔG|", "|ΔB|"):
            return f"{value:.0f}"

        if metric_name == "RGB Euclidean":
            return f"{value:.2f}"

        if metric_name == "|Δh°|":
            return f"{value:.2f}°"

        return f"{value:.3f}"


    @staticmethod
    def _get_ranking_metric_value(item):
        """
        Retrieve metric value from ranking item, preserving backwards compatibility.
        """
        if not isinstance(item, dict):
            return None

        return item.get("metric_value", item.get("delta_e"))


    @staticmethod
    def valid_projection_request(points, source_space="LAB", display_space="LAB"):
        """Return False for unsupported modes or non-finite/non-3D coordinates."""
        if (str(source_space).strip().upper() not in ("LAB", "RGB") or
                str(display_space).strip().upper() not in ("LAB", "RGB")):
            return False
        try:
            matrix = np.asarray(points, dtype=float)
        except (ValueError, TypeError):
            return False
        return (matrix.ndim >= 1 and matrix.shape[-1] == 3
                and bool(np.all(np.isfinite(matrix))))

    @staticmethod
    def reproject_points(points, source_space="LAB", display_space="LAB"):
        """Reproject ONLY 3D visualization coordinates, never membership geometry.

        CIELAB -> sRGB is gamut-clipped, so transformed polygons approximate
        the geometric surface (they are not new Voronoi polytopes in sRGB).
        """
        from skimage import color as skcolor

        src = str(source_space).strip().upper()
        dst = str(display_space).strip().upper()
        if src not in ("LAB", "RGB") or dst not in ("LAB", "RGB"):
            raise ValueError("Visualization supports LAB and RGB only.")
        arr = np.asarray(points, dtype=float)
        if arr.shape[-1] != 3 or not np.all(np.isfinite(arr)):
            raise ValueError("Color coordinates must be finite triplets.")
        if src == dst:
            return arr.copy()
        original_shape = arr.shape
        matrix = arr.reshape(-1, 3)
        with np.errstate(invalid="ignore", over="ignore", under="ignore"):
            if src == "LAB":
                # Out-of-gamut LAB vertices occur in clipped reference domains.
                # They are intentionally clipped for display; never change
                # the stored model or its membership calculations.
                import warnings
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", category=UserWarning,
                                             message="Conversion from CIE-LAB.*")
                    out = skcolor.lab2rgb(matrix.reshape(-1, 1, 3)).reshape(-1, 3)
                out = np.clip(out * 255.0, 0.0, 255.0)
            else:
                out = skcolor.rgb2lab(
                    np.clip(matrix, 0, 255).reshape(-1, 1, 3) / 255.0
                ).reshape(-1, 3)
        if not np.all(np.isfinite(out)):
            raise ValueError("Color coordinates cannot be displayed in this space.")
        return out.reshape(original_shape)

    @staticmethod
    def display_limits(volume_limits, source_space="LAB", display_space="LAB"):
        if str(source_space).upper() == str(display_space).upper():
            return volume_limits
        from Source.colorspace.ReferenceDomain import ReferenceDomain
        return ReferenceDomain.for_color_space(display_space)

    @staticmethod
    def _threshold_plot_groups(filtered_points):
        """Accept legacy per-volume points or named PT/AT plot layers.

        The named representation supports plotting PT and the additional
        AT-only shell independently. Every layer is a Volume_N -> points dict.
        """
        if not filtered_points:
            return []
        if any(name in filtered_points for name in ("PT", "AT", "AT_ONLY")):
            styles = (
                ("AT_ONLY", "AT only (0.8–1.8)", "#e49a34"),
                ("AT", "Acceptability (AT)", "#e49a34"),
                ("PT", "Perceptibility (PT)", "#3478d4"),
            )
            return [(label, color, filtered_points[name])
                    for name, label, color in styles
                    if name in filtered_points and filtered_points[name]]
        return [("Threshold-qualified", "#cf4f54", filtered_points)]

    # Embedded Matplotlib 3D Model

    @staticmethod
    def plot_combined_3D(
        ax,
        filename,
        color_data,
        core,
        alpha,
        support,
        volume_limits,
        hex_color,
        selected_options,
        filtered_points=None,
        color_space="LAB",
        display_color_space=None,
        reuse_surface_collection=False,
    ):
        """
        Draw the complete 3D model on an existing Axes3D instance.

        This function reuses the provided axis instead of creating a new figure
        every time. That makes repeated updates much cheaper.
        """
        cache = getattr(ax, "_pyfcs_recent_surfaces", []) if reuse_surface_collection else []
        active_artist = getattr(ax, "_pyfcs_surface_artist", None)
        if active_artist is not None and active_artist.axes is ax:
            active_artist.remove()
        ax._pyfcs_surface_artist = None
        ax.cla()
        if not reuse_surface_collection:
            ax._pyfcs_recent_surfaces = []
        display_color_space = (display_color_space or color_space).upper()
        target_limits = VisualManager.display_limits(volume_limits, color_space, display_color_space)
        to_display = lambda xyz: VisualManager.reproject_points(xyz, color_space, display_color_space)

        data_map = {
            "Representative": color_data,
            "0.5-cut": alpha,
            "Core": core,
            "Support": support,
        }

        def lab_to_key(lab):
            return tuple(np.round(np.asarray(lab, dtype=float), 6))

        inverse_hex_color = {
            lab_to_key(lab_val): hex_key
            for hex_key, lab_val in hex_color.items()
        }

        threshold_groups = VisualManager._threshold_plot_groups(filtered_points)

        # Representative points
        if "Representative" in selected_options and isinstance(color_data, dict):
            lab_values = [value["positive_prototype"] for value in color_data.values()]

            if lab_values:
                lab_array = to_display(np.asarray(lab_values, dtype=float))

                colors = [
                    inverse_hex_color.get(lab_to_key(lab))
                    or VisualManager._fallback_model_hex(lab, color_space)
                    for lab in lab_values
                ]

                ax.scatter(
                    lab_array[:, 1],
                    lab_array[:, 2],
                    lab_array[:, 0],
                    c=colors,
                    s=30,
                    edgecolor="k",
                    linewidths=0.6,
                    alpha=0.8,
                    depthshade=False,
                )

        # Sort the surfaces from ALL selected layers together.  Separate
        # transparent Poly3DCollections are sorted as whole objects by mplot3d;
        # with nested Core / 0.5-cut / Support volumes this produces the odd
        # dark patches that depend on the camera angle. One collection allows
        # face-by-face depth sorting and per-layer alpha values.
        active_layers = [name for name in ("Core", "0.5-cut", "Support")
                         if name in selected_options and data_map.get(name)]
        all_faces = []
        all_facecolors = []
        all_edgecolors = []
        surface_keys = []
        surface_refs = []
        multiple_layers = len(active_layers) > 1
        primary_layer = active_layers[0] if active_layers else None
        solo_alpha = {"Core": 0.38, "0.5-cut": 0.30, "Support": 0.18}
        # Keep the inner layer legible but make outer translucent shells much
        # lighter when more than one nested volume is selected.
        nested_alpha = {"Core": 0.34, "0.5-cut": 0.18, "Support": 0.07}

        for option in active_layers:
            prototypes = data_map[option]
            opacity = (solo_alpha[option] if not multiple_layers
                       else (nested_alpha[option] if option == primary_layer
                             else nested_alpha[option] * 0.80))
            # The real clipping caps MUST remain in the visible geometry;
            # otherwise the domain-bounded volumes appear open or triangular.
            # Their rendering never changes the functional membership faces.
            for prototype in prototypes:
                color = (inverse_hex_color.get(lab_to_key(prototype.positive))
                         or VisualManager._fallback_model_hex(
                             prototype.positive, color_space))
                valid_faces = VisualManager._cached_projected_display_faces(
                    prototype, volume_limits, color_space, display_color_space)
                # The same material is applied to every polygon of a given
                # prototype/layer. Prepare it once rather than per face.
                face_rgba = to_rgba(color, opacity)
                edge_alpha = (0.34 if option == primary_layer else 0.16)
                if not multiple_layers:
                    edge_alpha = 0.48 if option == "Core" else 0.38
                edge_rgba = (0.08, 0.08, 0.08, edge_alpha)
                surface_keys.append((id(valid_faces), face_rgba, edge_rgba))
                surface_refs.append(valid_faces)
                all_faces.extend(valid_faces)
                all_facecolors.extend([face_rgba] * len(valid_faces))
                all_edgecolors.extend([edge_rgba] * len(valid_faces))


        if all_faces:
            # Reuse a few recently toggled layer combinations. Keep strong
            # references to projected polygon lists, preventing identity reuse
            # after a geometry cache invalidation. The camera still performs
            # the full depth sort on every paint (no simplified geometry).
            key = (tuple(surface_keys), multiple_layers)
            item = next((entry for entry in cache if entry[0] == key), None)
            if item is not None:
                cache.remove(item)
                collection = item[1]
            else:
                collection = Poly3DCollection(
                    all_faces, facecolors=all_facecolors, edgecolors=all_edgecolors,
                    linewidths=0.26 if multiple_layers else 0.34, zsort="average")
                item = (key, collection, surface_refs, len(all_faces))
            ax.add_collection3d(collection)
            ax._pyfcs_surface_artist = collection
            if reuse_surface_collection and len(all_faces) <= 8000:
                cache.insert(0, item)
                # Bound both the number of cached combinations and their total size.
                while len(cache) > 3 or sum(entry[3] for entry in cache) > 16000:
                    cache.pop()
        if reuse_surface_collection:
            ax._pyfcs_recent_surfaces = cache

        # Threshold samples were already geometry-checked by the search.
        # Draw each sample ONCE, even if Core / 0.5-cut / Support are all shown.
        for group_label, group_color, group_points in threshold_groups:
            valid_arrays = [np.asarray(points, dtype=float)
                            for points in group_points.values() if points]
            if not valid_arrays:
                continue
            plot_points = to_display(np.concatenate(valid_arrays, axis=0))
            ax.scatter(plot_points[:, 1], plot_points[:, 2], plot_points[:, 0],
                       c=group_color, marker="o", s=9, alpha=0.8,
                       depthshade=False, label=group_label)
        if len(threshold_groups) > 1:
            ax.legend(loc="lower left", fontsize=8, framealpha=0.88)

        if str(display_color_space).upper() == "RGB":
            ax.set_xlabel("G (Green)", fontsize=10, labelpad=10)
            ax.set_ylabel("B (Blue)", fontsize=10, labelpad=10)
            ax.set_zlabel("R (Red)", fontsize=10, labelpad=10)
        else:
            ax.set_xlabel("a* (Green-Red)", fontsize=10, labelpad=10)
            ax.set_ylabel("b* (Blue-Yellow)", fontsize=10, labelpad=10)
            ax.set_zlabel("L* (Lightness)", fontsize=10, labelpad=10)

        if target_limits:
            ax.set_xlim(target_limits.comp2)
            ax.set_ylim(target_limits.comp3)
            ax.set_zlim(target_limits.comp1)

        # The embedding UI owns the title/subtitle styling and positioning.
        ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.7)

        try:
            ax.set_box_aspect((1, 1, 1))
        except Exception:
            pass

        VisualManager.draw_orientation_inset(
            ax.get_figure(), ax, display_color_space)


    @staticmethod
    def get_orientation_inset(fig):
        """Return the 2D orientation control if the figure owns one."""
        if fig is None:
            return None
        return next((a for a in fig.axes
                     if getattr(a, "_is_orientation_inset", False)), None)

    @staticmethod
    def draw_orientation_inset(fig, ax_main=None, color_space="LAB"):
        """Draw the original fixed 3D axis glyph, also supporting RGB.

        This is a static orientation reference, not a second camera. Clicking
        it is handled by the Tk host and resets the main camera. Unlike an
        orientation compass it does not follow the main camera rotation.
        """
        color_space = str(color_space).upper()
        if color_space not in ("LAB", "RGB"):
            color_space = "LAB"
        inset = VisualManager.get_orientation_inset(fig)
        if inset is not None:
            if getattr(inset, "_orientation_color_space", None) == color_space:
                return inset
            fig.delaxes(inset)

        # Restore the original dimensions, elevation and quiver rendering.
        # Lower-left corner, close to the plot frame.  Keep the original
        # quiver/text glyph but avoid the oversized empty 3D inset box.
        inset = fig.add_axes([0.0, -0.06, 0.16, 0.21], projection="3d")
        inset._is_orientation_inset = True
        inset._orientation_color_space = color_space
        inset.set_zorder(10)
        inset.set_facecolor((1, 1, 1, 0))
        inset.patch.set_alpha(0)
        inset.view_init(elev=30, azim=-60)
        inset.set_xlim(-1.2, 1.2)
        inset.set_ylim(-1.2, 1.2)
        inset.set_zlim(-1.2, 1.2)
        inset.set_xticks([])
        inset.set_yticks([])
        inset.set_zticks([])
        inset.set_xlabel("")
        inset.set_ylabel("")
        inset.set_zlabel("")
        inset.set_axis_off()
        # Disabling navigation alone is not sufficient on every Matplotlib
        # version: disable the Axes3D mouse-rotation handlers as well.
        inset.set_navigate(False)
        if hasattr(inset, "disable_mouse_rotation"):
            inset.disable_mouse_rotation()
        else:
            try:
                inset.mouse_init(rotate_btn=[], zoom_btn=[], pan_btn=[])
            except TypeError:
                inset.mouse_init(rotate_btn=[])
        try:
            for axis in (inset.xaxis, inset.yaxis, inset.zaxis):
                axis.pane.fill = False
                axis.pane.set_edgecolor((1, 1, 1, 0))
        except (AttributeError, TypeError):
            pass

        if color_space == "RGB":
            # PyFCS plots RGB with x=G, y=B, z=R.
            directions = (
                (0, 0, 1, "red"),
                (1, 0, 0, "green"),
                (0, 1, 0, "blue"),
            )
            for dx, dy, dz, color in directions:
                inset.quiver(0, 0, 0, dx, dy, dz, color=color,
                             arrow_length_ratio=0.20)
            inset.text(0.03, -0.02, 1.19, "R", fontsize=8, color="red")
            inset.text(1.19, -0.05, 0, "G", fontsize=8, color="green")
            inset.text(0.06, 1.19, 0, "B", fontsize=8, color="blue")
        else:
            # Original CIELAB glyph: x=a*, y=b*, z=L*.
            directions = (
                (1, 0, 0, "red"), (-1, 0, 0, "green"),
                (0, 1, 0, "gold"), (0, -1, 0, "blue"),
                (0, 0, 1, "gray"), (0, 0, -1, "black"),
            )
            for dx, dy, dz, color in directions:
                inset.quiver(0, 0, 0, dx, dy, dz, color=color,
                             arrow_length_ratio=0.20)
            inset.text(1.18, -0.05, 0, "+a*", fontsize=8)
            inset.text(-1.32, 0.02, 0.02, "-a*", fontsize=8)
            inset.text(0.06, 1.18, 0.02, "+b*", fontsize=8)
            inset.text(-0.10, -1.34, -0.08, "-b*", fontsize=8)
            inset.text(0.02, 0.02, 1.18, "+L*", fontsize=8)
            inset.text(0.04, -0.08, -1.34, "-L*", fontsize=8)
        return inset

    @staticmethod
    def update_orientation_inset(inset, ax_main=None, force=False):
        """Compatibility hook: the static inset must never track the camera."""
        return inset


    # General Interactive Plotly 3D Model

    @staticmethod
    def plot_more_combined_3D(
        filename,
        color_data,
        core,
        alpha,
        support,
        volume_limits,
        hex_color,
        selected_options=None,
        filtered_points=None,
        custom_lab=None,
        custom_hex="#ff0000",
        closest_label=None,
        closest_lab=None,
        closest_hex="#000000",
        color_space="LAB",
        display_color_space=None,
        granule_categories=None,
    ):
        """
        Generate a unified interactive Plotly 3D figure.

        Features
        --------
        - Representative / Core / 0.5-cut / Support can be toggled independently.
        - Several volume layers can be superimposed at once.
        - Select/Deselect all colors respects the currently displayed geometry.
        - Optional custom/sample color is drawn as a smaller diamond.
        - Optional closest prototype is highlighted.
        - Optional custom-to-closest distance line can be toggled with a button.
        - Layout adapts its height when many colors are shown.
        """

        traces = []
        display_color_space = (display_color_space or color_space).upper()
        target_limits = VisualManager.display_limits(volume_limits, color_space, display_color_space)
        to_display = lambda xyz: VisualManager.reproject_points(xyz, color_space, display_color_space)

        color_data = color_data or {}
        selected_options = ["Representative"] if selected_options is None else selected_options

        title_text = str(filename).split("|")[0].strip()

        # Normalize layer names.
        def _normalize_option(option):
            text = str(option).strip().lower()

            if text in ("representative", "representatives", "centroid", "centroids"):
                return "Representative"

            if text == "core":
                return "Core"

            if text in ("0.5-cut", "0.5cut", "0.5 cut", "alpha", "alpha-cut", "alphacut"):
                return "0.5-cut"

            if text in ("support", "suppport"):
                return "Support"

            return str(option).strip()

        selected_options = {
            _normalize_option(option)
            for option in selected_options
        }

        custom_lab = VisualManager._safe_lab(custom_lab)
        closest_lab = VisualManager._safe_lab(closest_lab)

        # Resolve the comparison prototype from its label or LAB distance.
        if custom_lab is not None and closest_lab is None:
            # Try to recover closest_lab from closest_label.
            if closest_label is not None:
                for label, value in color_data.items():
                    if str(label) != str(closest_label):
                        continue

                    try:
                        inferred_lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        closest_lab = inferred_lab
                        closest_hex = VisualManager._find_hex_for_lab(
                            closest_lab,
                            hex_color,
                            default=closest_hex,
                        )
                        break
                    except Exception:
                        continue

            # If closest_label was not available or did not match, compute closest LAB point.
            if closest_lab is None:
                best_label = None
                best_lab = None
                best_hex = closest_hex
                best_distance = float("inf")

                for label, value in color_data.items():
                    try:
                        lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        distance = float(np.linalg.norm(custom_lab - lab))

                        if distance < best_distance:
                            best_distance = distance
                            best_label = str(label)
                            best_lab = lab
                            best_hex = VisualManager._find_hex_for_lab(
                                lab,
                                hex_color,
                                default=closest_hex,
                            )
                    except Exception:
                        continue

                if best_lab is not None:
                    closest_label = best_label
                    closest_lab = best_lab
                    closest_hex = best_hex

        has_distance_line = custom_lab is not None and closest_lab is not None

        # Dynamic figure height.
        # Scale figure height with the number of legend entries.
        n_colors = len(color_data)
        figure_height = max(760, min(1250, 520 + n_colors * 15))

        layer_names = ("Representative", "Core", "0.5-cut", "Support")

        layer_opacity = {
            "Representative": 0.96,
            "Core": 0.42,
            "0.5-cut": 0.26,
            "Support": 0.16,
        }
        active_volumes = [name for name in ("Core", "0.5-cut", "Support")
                          if name in selected_options]
        if len(active_volumes) > 1:
            # Plotly also has transparency-ordering limitations with nested
            # Mesh3d traces; avoid opaque-looking stacked shells.
            soft_opacity = {"Core": 0.34, "0.5-cut": 0.15, "Support": 0.055}
            for name in active_volumes:
                layer_opacity[name] = (soft_opacity[name] if name == active_volumes[0]
                                       else soft_opacity[name] * 0.8)

        marker_sizes = {
            "Representative": 5.8,
            "Custom": 6.4,
            "Closest": 6.4,
        }

        layer_indices = {
            "Representative": [],
            "Core": [],
            "0.5-cut": [],
            "Support": [],
            "Distance line": [],
        }

        color_control_indices = []
        legend_labels_added = set()

        # The plot draws the same prototypes in several layers. Resolve the
        # representative-to-HEX lookup once instead of scanning the palette
        # for every marker and every mesh. Retain the first-match semantics.
        hex_lookup = {}
        if isinstance(hex_color, dict):
            for candidate_hex, candidate_value in hex_color.items():
                try:
                    hex_lookup.setdefault(VisualManager._lab_key(candidate_value),
                                          candidate_hex)
                except (ValueError, TypeError):
                    continue

        def _prototype_hex_from_lab(lab):
            return (hex_lookup.get(VisualManager._lab_key(lab))
                    or VisualManager._fallback_model_hex(lab, color_space))

        def _safe_label(value):
            try:
                return str(value)
            except Exception:
                return "Prototype"

        def _initial_opacity(layer_name):
            return layer_opacity[layer_name] if layer_name in selected_options else 0.0

        def _add_legend_anchor(label, proto_hex, rank, group_label=None):
            """
            Add one visible legend item per prototype.

            These dummy traces carry the legend entries. The real geometry traces
            share the same legendgroup but do not appear separately in the legend.
            """
            label = _safe_label(label)
            group_label = str(group_label) if group_label is not None else label

            if group_label in legend_labels_added:
                return

            traces.append(
                go.Scatter3d(
                    x=[None],
                    y=[None],
                    z=[None],
                    mode="markers",
                    marker=dict(
                        size=7,
                        color=proto_hex,
                        line=dict(color="black", width=0.8),
                    ),
                    opacity=1.0,
                    visible=True,
                    name=label,
                    legendgroup=group_label,
                    showlegend=True,
                    legendrank=rank,
                    hoverinfo="skip",
                )
            )

            trace_idx = len(traces) - 1
            color_control_indices.append(trace_idx)
            legend_labels_added.add(group_label)

        # Legend anchors first.
        for rank, (label, value) in enumerate(color_data.items()):
            try:
                lab = np.asarray(value["positive_prototype"], dtype=float).reshape(-1)[:3]
            except Exception:
                continue

            proto_hex = _prototype_hex_from_lab(lab)
            category = (granule_categories or {}).get(label)
            legend_name = f"{category} · {label}" if category else label
            _add_legend_anchor(legend_name, proto_hex, rank, group_label=label)

        # Representative points.
        for label, value in color_data.items():
            try:
                lab = np.asarray(value["positive_prototype"], dtype=float).reshape(-1)[:3]
            except Exception:
                continue

            label = _safe_label(label)
            proto_hex = _prototype_hex_from_lab(lab)

            is_closest = closest_label is not None and label == str(closest_label)
            category = (granule_categories or {}).get(label)
            shown = to_display(lab)

            traces.append(
                go.Scatter3d(
                    x=[shown[1]],
                    y=[shown[2]],
                    z=[shown[0]],
                    mode="markers",
                    marker=dict(
                        size=7.6 if is_closest else marker_sizes["Representative"],
                        color=proto_hex,
                        line=dict(
                            color="black",
                            width=2.4 if is_closest else 0.9,
                        ),
                    ),
                    opacity=_initial_opacity("Representative"),
                    visible=True,
                    name=label,
                    legendgroup=label,
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{label}</b><br>"
                        + (f"Category: {category}<br>" if category else "")
                        + ("R: %{z:.2f}<br>G: %{x:.2f}<br>B: %{y:.2f}<extra></extra>"
                           if display_color_space == "RGB" else
                           "L*: %{z:.3f}<br>a*: %{x:.3f}<br>b*: %{y:.3f}<extra></extra>")
                    ),
                )
            )

            trace_idx = len(traces) - 1
            layer_indices["Representative"].append(trace_idx)
            color_control_indices.append(trace_idx)

        # Volumes: Core / 0.5-cut / Support.
        volume_sources = {
            "Core": core,
            "0.5-cut": alpha,
            "Support": support,
        }

        for layer_name, prototypes in volume_sources.items():
            if not prototypes:
                continue

            for prototype in prototypes:
                try:
                    proto_label = _safe_label(prototype.label)
                    proto_hex = _prototype_hex_from_lab(prototype.positive)
                except Exception:
                    continue

                try:
                    mesh = VisualManager._cached_plotly_display_mesh(
                        prototype, volume_limits, color_space, display_color_space)
                except (ValueError, TypeError, ArithmeticError):
                    continue
                if mesh is None:
                    continue
                vertices, i_indices, j_indices, k_indices = mesh

                traces.append(
                    go.Mesh3d(
                        x=vertices[:, 0],
                        y=vertices[:, 1],
                        z=vertices[:, 2],
                        i=i_indices,
                        j=j_indices,
                        k=k_indices,
                        color=proto_hex,
                        opacity=_initial_opacity(layer_name),
                        visible=True,
                        name=f"{layer_name}: {proto_label}",
                        legendgroup=proto_label,
                        showlegend=False,
                        hoverinfo="skip",
                        flatshading=False,
                        lighting=dict(
                            ambient=0.58,
                            diffuse=0.72,
                            specular=0.18,
                            roughness=0.82,
                            fresnel=0.08,
                        ),
                        lightposition=dict(
                            x=120,
                            y=160,
                            z=240,
                        ),
                    )
                )

                trace_idx = len(traces) - 1
                layer_indices[layer_name].append(trace_idx)
                color_control_indices.append(trace_idx)

        # Optional threshold samples. A combined result consists of two
        # disjoint layers: PT and AT_ONLY; AT already includes PT.
        def _plot_filtered_points(reference_prototypes):
            if not filtered_points or not reference_prototypes:
                return
            groups = VisualManager._threshold_plot_groups(filtered_points)
            for group_label, group_color, group_points in groups:
                for proto_name, points in group_points.items():
                    try:
                        proto_idx = int(str(proto_name).split("_")[-1])
                    except (ValueError, TypeError):
                        continue
                    if not (0 <= proto_idx < len(reference_prototypes)) or not points:
                        continue
                    prototype = reference_prototypes[proto_idx]
                    proto_label = _safe_label(prototype.label)
                    pts = to_display(np.asarray(points, dtype=float))
                    if pts.ndim != 2 or pts.shape[1] != 3:
                        continue
                    point_size = max(2, min(6, int(300 / len(points))))
                    traces.append(go.Scatter3d(
                        x=pts[:, 1], y=pts[:, 2], z=pts[:, 0],
                        mode="markers",
                        marker=dict(size=point_size, color=group_color),
                        opacity=0.68, visible=True,
                        name=f"{group_label} – {proto_label}",
                        legendgroup=group_label,
                        showlegend=(proto_idx == 0 and len(groups) > 1),
                        hovertemplate=(
                            f"<b>{group_label} – {proto_label}</b><br>" +
                            ("R: %{z:.2f}<br>G: %{x:.2f}<br>B: %{y:.2f}<extra></extra>"
                             if display_color_space == "RGB" else
                             "L*: %{z:.3f}<br>a*: %{x:.3f}<br>b*: %{y:.3f}<extra></extra>")
                        ),
                    ))
                    color_control_indices.append(len(traces) - 1)

        preferred_prototypes = (
            support if "Support" in selected_options else
            alpha if "0.5-cut" in selected_options else core
        )
        _plot_filtered_points(preferred_prototypes)

        if closest_lab is not None:
            closest_lab = to_display(closest_lab)
        if custom_lab is not None:
            custom_lab = to_display(custom_lab)
            traces.append(
                go.Scatter3d(
                    x=[custom_lab[1]],
                    y=[custom_lab[2]],
                    z=[custom_lab[0]],
                    mode="markers",
                    marker=dict(
                        size=marker_sizes["Custom"],
                        color=custom_hex,
                        symbol="diamond",
                        line=dict(color="black", width=1.7),
                    ),
                    opacity=1.0,
                    visible=True,
                    name="Custom color",
                    legendgroup="__custom__",
                    showlegend=True,
                    legendrank=10_000,
                    hovertemplate=(
                        "<b>Custom color</b><br>"
                        + ("R: %{z:.2f}<br>G: %{x:.2f}<br>B: %{y:.2f}<extra></extra>"
                           if display_color_space == "RGB" else
                           "L*: %{z:.3f}<br>a*: %{x:.3f}<br>b*: %{y:.3f}<extra></extra>")
                    ),
                )
            )

        # Optional closest prototype highlight.
        if closest_lab is not None:
            traces.append(
                go.Scatter3d(
                    x=[closest_lab[1]],
                    y=[closest_lab[2]],
                    z=[closest_lab[0]],
                    mode="markers",
                    marker=dict(
                        size=marker_sizes["Closest"],
                        color=closest_hex,
                        symbol="circle",
                        line=dict(color="black", width=3.2),
                    ),
                    opacity=1.0,
                    visible=True,
                    name=f"Closest: {closest_label}",
                    legendgroup="__closest__",
                    showlegend=True,
                    legendrank=10_001,
                    hovertemplate=(
                        f"<b>Closest: {closest_label}</b><br>"
                        + ("R: %{z:.2f}<br>G: %{x:.2f}<br>B: %{y:.2f}<extra></extra>"
                           if display_color_space == "RGB" else
                           "L*: %{z:.3f}<br>a*: %{x:.3f}<br>b*: %{y:.3f}<extra></extra>")
                    ),
                )
            )

        # Optional custom-to-closest line.
        # It appears active by default.
        # The user can still click it in the legend to show/hide it.
        if has_distance_line:
            traces.append(
                go.Scatter3d(
                    x=[custom_lab[1], closest_lab[1]],
                    y=[custom_lab[2], closest_lab[2]],
                    z=[custom_lab[0], closest_lab[0]],
                    mode="lines",
                    line=dict(
                        color="black",
                        width=4,
                        dash="dash",
                    ),
                    opacity=1.0,
                    visible=True,
                    name=f"Custom → closest line ({closest_label})",
                    legendgroup="__distance__",
                    showlegend=True,
                    legendrank=10_002,
                    hoverinfo="skip",
                )
            )

            layer_indices["Distance line"].append(len(traces) - 1)

        # Displayed geometry buttons.
        # Layer controls change opacity; hidden layers remain hidden on Select All.
        layer_button_positions = {
            "Representative": 0.020,
            "Core": 0.150,
            "0.5-cut": 0.210,
            "Support": 0.290,
        }

        layer_menus = []

        for layer_name in layer_names:
            indices = layer_indices.get(layer_name, [])

            layer_menus.append(
                dict(
                    type="buttons",
                    direction="right",
                    x=layer_button_positions[layer_name],
                    y=0.925,
                    xanchor="left",
                    yanchor="top",
                    active=0 if layer_name in selected_options else -1,
                    showactive=True,
                    buttons=[
                        dict(
                            label=layer_name,
                            method="restyle",
                            args=[{"opacity": layer_opacity[layer_name]}, indices],
                            args2=[{"opacity": 0.0}, indices],
                        )
                    ],
                    pad=dict(r=1, t=1, b=1),
                )
            )

        # Color visibility buttons.
        # Color visibility controls retain each layer's current opacity.
        color_buttons = [
            dict(
                label="Select all colors",
                method="restyle",
                args=[{"visible": True}, color_control_indices],
            ),
            dict(
                label="Deselect all colors",
                method="restyle",
                args=[{"visible": "legendonly"}, color_control_indices],
            ),
        ]

        color_menu = dict(
            type="buttons",
            direction="down",
            x=0.992,
            y=0.925,
            xanchor="right",
            yanchor="top",
            active=-1,
            showactive=False,
            buttons=color_buttons,
            pad=dict(r=1, t=1, b=1),
        )

        xaxis_range = target_limits.comp2 if target_limits else None
        yaxis_range = target_limits.comp3 if target_limits else None
        zaxis_range = target_limits.comp1 if target_limits else None

        # Legend.
        # Keep the legend at the right edge without version-specific size options.
        legend_config = dict(
            x=0.992,
            y=0.790,
            xanchor="right",
            yanchor="top",
            title=dict(text="Colors"),
            groupclick="togglegroup",
            bgcolor="rgba(255,255,255,0.96)",
            bordercolor="rgba(0,0,0,0.12)",
            borderwidth=1,
            font=dict(size=9, color="#3F374C"),
            itemsizing="constant",
            tracegroupgap=0,
        )

        layout_annotations = [
            dict(
                text="<b>Color visibility</b>",
                x=0.992,
                y=0.955,
                xref="paper",
                yref="paper",
                showarrow=False,
                xanchor="right",
                yanchor="top",
                font=dict(size=12, color="#3F374C"),
            ),
        ]

        # One bulk construction avoids a figure mutation for each mesh.
        fig = go.Figure(data=traces)
        fig.update_layout(
            height=figure_height,
            title=dict(
                text=title_text,
                x=0.385,
                y=0.990,
                xanchor="center",
                yanchor="top",
                font=dict(
                    size=17,
                    family="Arial, sans-serif",
                    color="#3F374C",
                ),
            ),
            scene=dict(
                domain=dict(
                    x=[0.005, 0.765],
                    y=[0.015, 0.895],
                ),
                xaxis=dict(
                    title=("G (Green)" if display_color_space == "RGB" else "a*  (green ↔ red)"),
                    range=xaxis_range,
                    backgroundcolor="#f7f8fa",
                    gridcolor="white",
                    zerolinecolor="#c9ced8",
                    showbackground=True,
                    showspikes=False,
                ),
                yaxis=dict(
                    title=("B (Blue)" if display_color_space == "RGB" else "b*  (blue ↔ yellow)"),
                    range=yaxis_range,
                    backgroundcolor="#f7f8fa",
                    gridcolor="white",
                    zerolinecolor="#c9ced8",
                    showbackground=True,
                    showspikes=False,
                ),
                zaxis=dict(
                    title=("R (Red)" if display_color_space == "RGB" else "L*  (lightness)"),
                    range=zaxis_range,
                    backgroundcolor="#f7f8fa",
                    gridcolor="white",
                    zerolinecolor="#c9ced8",
                    showbackground=True,
                    showspikes=False,
                ),
                camera=dict(
                    eye=dict(x=1.55, y=1.65, z=1.18),
                    up=dict(x=0, y=0, z=1),
                    projection=dict(type="orthographic"),
                ),
                aspectmode="cube",
            ),
            updatemenus=layer_menus + [color_menu],
            annotations=layout_annotations,
            legend=legend_config,
            margin=dict(
                l=8,
                r=8,
                b=8,
                t=58,
            ),
            paper_bgcolor="white",
            plot_bgcolor="white",
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#3F374C",
                font=dict(color="#3F374C"),
            ),
        )

        if str(color_space).upper() == "RGB":
            for trace in fig.data:
                tmpl = getattr(trace, "hovertemplate", None)
                if isinstance(tmpl, str):
                    trace.hovertemplate = (tmpl.replace("L*:", "R:")
                                               .replace("a*:", "G:")
                                               .replace("b*:", "B:"))

        return fig


    @staticmethod
    def write_model_3d_html(fig, file_path, color_tree):
        """Export Model 3D with a responsive, independently scrolling color tree.

        The figure is not modified. Color visibility and layer visibility are
        independent; every real Plotly trace belongs to a single granule.
        The desktop selection defines the subset exported to the browser.
        """
        import html
        import json
        from pathlib import Path

        # The native legend and menus overlap in large spaces. Keep Plotly's
        # camera, modebar and meshes, but move these controls outside its canvas.
        exported = go.Figure(fig)
        layers = []
        anchors = set()
        colors = {}
        extras = {}
        groups = {}
        for index, trace in enumerate(exported.data):
            group = str(trace.legendgroup or '')
            if not group:
                continue
            if (trace.type == 'scatter3d' and trace.showlegend is True
                    and trace.x is not None and len(trace.x) == 1 and trace.x[0] is None):
                anchors.add(index)
                colors[group] = str(trace.marker.color)
            else:
                groups.setdefault(group, []).append(index)
                if trace.showlegend:
                    extras.setdefault(group, str(trace.name))
        for group in groups:
            if group not in colors and group not in extras:
                extras[group] = group
        for menu in exported.layout.updatemenus or ():
            if not menu.buttons or len(menu.buttons) != 1:
                continue
            button = menu.buttons[0]
            args = button.args
            if not args or 'opacity' not in args[0]:
                continue
            layers.append(dict(name=button.label, indices=list(args[1]),
                               opacity=float(args[0]['opacity']), active=menu.active == 0))
        for index in anchors:
            exported.data[index].visible = False
        title = str(exported.layout.title.text or 'Model 3D')
        exported.layout.updatemenus = ()
        exported.layout.annotations = ()
        exported.update_layout(height=None, width=None, autosize=True, showlegend=False,
                               title=dict(text=''),
                               margin=dict(l=8, r=8, t=32, b=8), uirevision='pyfcs-interactive')
        exported.update_layout(scene=dict(domain=dict(x=[0, 1], y=[0, 1]),
                                          uirevision='pyfcs-interactive'))
        payload = dict(tree=color_tree, colors=colors, groups=groups, extras=extras, layers=layers)
        # Do not interpolate user-provided names into executable JS or HTML.
        data = json.dumps(payload, ensure_ascii=True).replace('<', '\\u003c')
        script = r"""
const gd = document.getElementById('{plot_id}');
const payload = JSON.parse(document.getElementById('fcs-data').textContent);
const {tree, colors, groups, extras, layers} = payload;
const own = (o,k) => Object.prototype.hasOwnProperty.call(o,k);
const ids = Object.keys(colors).filter(id => own(groups,id));
const allowed = new Set(ids), active = new Set(ids), extraActive = new Set(Object.keys(extras));
const list = document.getElementById('color-tree'), search = document.getElementById('search');
const counter = document.getElementById('count'), expanded = new Set();
const descendants = new Map();
function leaves(kind,name) {
  if(kind==='granule') return allowed.has(name) ? [name] : [];
  if(descendants.has(name)) return descendants.get(name);
  const out = [...new Set((own(tree.children,name)?tree.children[name]:[]).flatMap(([k,n])=>leaves(k,n)))];
  descendants.set(name,out); return out;
}
const roots = tree.roots.filter(([k,n])=>leaves(k,n).length);
// Include any geometry not reachable via the supplied tree (legacy flat spaces).
const covered = new Set(roots.flatMap(([k,n])=>leaves(k,n)));
for(const id of ids) if(!covered.has(id)) roots.push(['granule',id]);
let rows=[];
function updateCounts(){
  counter.textContent=active.size+'/'+ids.length;
  for(const r of rows){
    const n=r.ids.filter(id=>active.has(id)).length;
    r.cb.checked=n===r.ids.length; r.cb.indeterminate=n>0&&n<r.ids.length;
    if(r.count) r.count.textContent=n+'/'+r.ids.length;
  }
  for(const box of list.querySelectorAll('[data-extra]')) box.checked=extraActive.has(box.dataset.extra);
}
function change(idsToChange,value){
  const indices=[], values=[];
  for(const id of idsToChange){
    if(active.has(id)===value) continue;
    if(value) active.add(id); else active.delete(id);
    for(const i of groups[id]||[]){indices.push(i);values.push(value);}
  }
  updateCounts();
  if(indices.length) enqueue({'visible':values},indices);
}
// Serialize updates; rapid clicks must not race Plotly's asynchronous restyle.
let queue=Promise.resolve();
function enqueue(update,indices){
  if(!indices.length) return;
  queue=queue.catch(console.error).then(()=>Plotly.restyle(gd,update,indices));
}
const norm=s=>s.toLocaleLowerCase();
const matchMemo=new Map();
function matches(kind,name,q){
  if(!q||norm(name).includes(q)) return true;
  if(kind==='granule') return false;
  if(matchMemo.has(name)) return matchMemo.get(name);
  const result=(own(tree.children,name)?tree.children[name]:[]).some(([k,n])=>leaves(k,n).length&&matches(k,n,q));
  matchMemo.set(name,result); return result;
}
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;}
function render(){
  const q=norm(search.value.trim()); matchMemo.clear(); rows=[]; list.replaceChildren();
  let truncated=false;
  function add(parent,kind,name,path,ancestorMatch){
    if(rows.length>=2000 || path.length>64){truncated=true;return;}
    const memberIds=leaves(kind,name); if(!memberIds.length) return;
    const selfMatch=ancestorMatch||norm(name).includes(q);
    if(q&&!selfMatch&&!matches(kind,name,q)) return;
    const category=kind==='category', key=JSON.stringify(path);
    const branch=el('div','branch'), row=el('div','color-row'); parent.append(branch);branch.append(row);
    if(category){
      const arrow=el('button','arrow',expanded.has(key)||q?'▾':'▸');arrow.type='button';
      arrow.setAttribute('aria-label','Expand '+name);arrow.setAttribute('aria-expanded',String(!!q||expanded.has(key)));
      arrow.onclick=()=>{if(expanded.has(key))expanded.delete(key);else expanded.add(key);render();};row.append(arrow);
    }else row.append(el('span','arrow-spacer'));
    const cb=el('input');cb.type='checkbox';cb.setAttribute('aria-label','Show '+name);row.append(cb);
    cb.onchange=()=>change(memberIds,cb.checked);
    const label=el('label','color-label'+(category?' category':''));
    const swatch=el('span','swatch');swatch.style.backgroundColor=colors[memberIds[0]];label.append(swatch,el('span','name',name));
    label.title=name;label.onclick=()=>cb.click();row.append(label);
    const count=memberIds.length>1?el('span','row-count'):null;if(count)row.append(count);
    rows.push({cb,ids:memberIds,count});
    if(category&&(q||expanded.has(key))){
      const childBox=el('div','children');branch.append(childBox);
      for(const [k,n] of (own(tree.children,name)?tree.children[name]:[])) add(childBox,k,n,path.concat([[k,n]]),selfMatch);
      if(!childBox.childElementCount)childBox.remove();
    }
  }
  for(const [k,n] of roots) add(list,k,n,[[k,n]],false);
  if(truncated) list.append(el('p','empty','Too many matching branches. Refine the search or collapse groups.'));
  if(!rows.length) list.append(el('p','empty','No matching colors.'));
  for(const [id,name] of Object.entries(extras)){
    if(q&&!norm(name).includes(q))continue;
    const row=el('label','extra-row'), cb=el('input');cb.type='checkbox';cb.dataset.extra=id;
    cb.onchange=()=>{if(cb.checked)extraActive.add(id);else extraActive.delete(id);enqueue({visible:cb.checked},groups[id]);};
    row.append(cb,el('span','name',name));list.append(row);
  }
  updateCounts();
}
function bulk(value){
  change(ids,value);
  const indices=[];
  for(const id of Object.keys(extras)) if(extraActive.has(id)!==value){
    if(value)extraActive.add(id);else extraActive.delete(id);indices.push(...groups[id]);
  }
  updateCounts();enqueue({visible:value},indices);
}
document.getElementById('select-all').onclick=()=>bulk(true);
document.getElementById('deselect-all').onclick=()=>bulk(false);
document.getElementById('clear-search').onclick=()=>{search.value='';render();};
search.addEventListener('input',render);
for(const layer of layers){
  const b=el('button','layer',layer.name);b.type='button';
  b.setAttribute('aria-pressed',String(layer.active));b.disabled=!layer.indices.length;
  b.onclick=()=>{layer.active=!layer.active;b.setAttribute('aria-pressed',String(layer.active));
    enqueue({opacity:layer.active?layer.opacity:0},layer.indices);};
  document.getElementById('layers').append(b);
}
render();
// CSS controls the figure height; resizing does not change the camera.
if(typeof ResizeObserver!=='undefined'){
  const area=document.getElementById('plot-area');
  new ResizeObserver(()=>{if(gd.isConnected && gd.clientWidth && gd.clientHeight)
    Promise.resolve(Plotly.Plots.resize(gd)).catch(()=>{});}).observe(area);
}
"""
        fragment = exported.to_html(full_html=False, include_plotlyjs=True,
                                    default_width='100%', default_height='100%',
                                    config=dict(responsive=True, displaylogo=False), post_script=script)
        style = """
*{box-sizing:border-box}html,body{height:100%;margin:0;font:14px Arial,sans-serif;color:#292535;background:white}
body{display:grid;grid-template-rows:auto minmax(0,1fr);height:100vh;height:100dvh;overflow:hidden}
header{padding:12px 18px 10px;border-bottom:1px solid #e0e2e8;display:flex;align-items:center;gap:18px;flex-wrap:wrap}
h1{font-size:19px;font-weight:600;margin:0;overflow-wrap:anywhere}#layers{display:flex;gap:7px;flex-wrap:wrap;margin-left:auto}
button{font:inherit;color:#68428f;background:white;border:1px solid #d3cbdc;padding:6px 9px;cursor:pointer;border-radius:3px}
button:hover{background:#f3eef8}button:disabled{cursor:default;opacity:.5}button[aria-pressed=true]{background:#eee6f6;border-color:#a992c5;font-weight:600}
main{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) clamp(225px,24vw,345px);gap:10px;padding:10px}
#plot-area{min-width:0;min-height:0;overflow:hidden}#plot-area>div{height:100%;width:100%}
aside{display:flex;flex-direction:column;min-width:0;min-height:0;border:1px solid #dfe1e6;padding:11px;gap:10px}
.heading{display:flex;justify-content:space-between;align-items:center;font-weight:bold}.heading span{color:#68428f}
.bulk{display:grid;grid-template-columns:1fr 1fr;gap:6px}.bulk button{background:#f0f2f5;color:#292535;font-size:12px;font-weight:600}
.search-row{display:flex;align-items:center;gap:6px;justify-content:center}.search-row input{min-width:0;width:100%;max-width:150px;border:1px solid #c9cdd4;padding:4px;font:inherit}.search-row button{padding:3px;border:0;color:#777}
#color-tree{flex:1;min-height:0;overflow:auto;scrollbar-width:thin;scrollbar-color:#c4cad3 #f1f3f6;padding-right:5px}
.color-row{display:flex;align-items:center;gap:5px;min-height:29px;padding:3px 0}.arrow,.arrow-spacer{width:14px;flex:0 0 14px}.arrow{padding:0;border:0;color:#68428f;font-size:15px;background:transparent}.color-row input,.extra-row input{margin:0;accent-color:#68428f;flex:none}
.color-label{display:flex;align-items:center;gap:6px;min-width:0;flex:1;cursor:pointer}.category{font-weight:600}.swatch{display:inline-block;width:16px;height:16px;flex:0 0 16px;border:1px solid #aaa}.name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}.row-count{font-size:12px;color:#68428f;flex:none}.children{margin-left:6px;padding-left:12px;border-left:1px solid #c9bfda}.children>.branch>.color-row{position:relative}.children>.branch>.color-row:before{content:'';position:absolute;left:-12px;width:10px;top:50%;border-top:1px solid #c9bfda}.extra-row{display:flex;gap:6px;align-items:center;padding:5px}.empty{color:#777;font-size:13px}
@media(max-width:600px){main{grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr) minmax(120px,35vh)}header{padding:8px;gap:5px}#layers{margin-left:0}h1{font-size:16px}aside{padding:6px;gap:5px}}
"""
        document = ('<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
                    '<meta name="viewport" content="width=device-width, initial-scale=1">'
                    '<title>'+html.escape(title)+'</title><style>'+style+
                    'main>aside{grid-column:2;grid-row:1}#plot-area{grid-column:1;grid-row:1}'
                    '@media(max-width:600px){main>aside{grid-column:1;grid-row:2}}</style></head><body>'
                    '<header><h1>'+html.escape(title)+'</h1><div id="layers" aria-label="Display layers"></div></header>'
                    '<script id="fcs-data" type="application/json">'+data+'</script>'
                    '<main><aside><div class="heading">Colors<span id="count"></span></div>'
                    '<div class="bulk"><button id="select-all">Select All</button><button id="deselect-all">Deselect All</button></div>'
                    '<div class="search-row"><label for="search">Search</label><input id="search" type="search">'
                    '<button id="clear-search">Clear</button></div><div id="color-tree"></div></aside>'
                    '<section id="plot-area">'+fragment+'</section></main></body></html>')
        Path(file_path).write_text(document, encoding='utf-8')

    @staticmethod
    def plot_color_evaluation_ab_projection(
        color_data,
        hex_color,
        custom_lab=None,
        custom_hex="#ff0000",
        closest_label=None,
        closest_lab=None,
        closest_hex="#000000",
        filename="Color evaluation",
    ):
        """
        2D a*b* projection with all prototypes.

        Works with or without a custom/sample color.
        If custom and closest colors are available, they are highlighted and connected.
        The default interaction mode is pan instead of zoom.
        """
        fig = go.Figure()

        color_data = color_data or {}
        custom_lab = VisualManager._safe_lab(custom_lab)
        closest_lab = VisualManager._safe_lab(closest_lab)

        # Resolve the comparison prototype from its label or LAB distance.
        if custom_lab is not None and closest_lab is None:
            if closest_label is not None:
                for label, value in color_data.items():
                    if str(label) != str(closest_label):
                        continue

                    try:
                        inferred_lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        closest_lab = inferred_lab
                        closest_hex = VisualManager._find_hex_for_lab(
                            closest_lab,
                            hex_color,
                            default=closest_hex,
                        )
                        break
                    except Exception:
                        continue

            if closest_lab is None:
                best_label = None
                best_lab = None
                best_hex = closest_hex
                best_distance = float("inf")

                for label, value in color_data.items():
                    try:
                        lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        distance = float(np.linalg.norm(custom_lab - lab))

                        if distance < best_distance:
                            best_distance = distance
                            best_label = str(label)
                            best_lab = lab
                            best_hex = VisualManager._find_hex_for_lab(
                                lab,
                                hex_color,
                                default=closest_hex,
                            )
                    except Exception:
                        continue

                if best_lab is not None:
                    closest_label = best_label
                    closest_lab = best_lab
                    closest_hex = best_hex

        has_distance_line = custom_lab is not None and closest_lab is not None

        # Draw connection line first, so markers remain above it.
        if has_distance_line:
            # Faint underlying stroke
            fig.add_trace(
                go.Scatter(
                    x=[custom_lab[1], closest_lab[1]],
                    y=[custom_lab[2], closest_lab[2]],
                    mode="lines",
                    line=dict(
                        color="rgba(255,255,255,0.95)",
                        width=6,
                    ),
                    showlegend=False,
                    hoverinfo="skip",
                )
            )

            # Foreground dashed stroke
            fig.add_trace(
                go.Scatter(
                    x=[custom_lab[1], closest_lab[1]],
                    y=[custom_lab[2], closest_lab[2]],
                    mode="lines",
                    line=dict(
                        color="rgba(35,54,79,0.95)",
                        width=2.6,
                        dash="dot",
                    ),
                    name="Custom → closest line",
                    showlegend=True,
                    hoverinfo="skip",
                )
            )

        for label, value in color_data.items():
            try:
                lab = np.asarray(value["positive_prototype"], dtype=float).reshape(-1)[:3]
            except Exception:
                continue

            proto_hex = VisualManager._find_hex_for_lab(
                lab,
                hex_color,
                default="#000000"
            )

            is_closest = (
                closest_label is not None
                and str(label) == str(closest_label)
            )

            fig.add_trace(
                go.Scatter(
                    x=[lab[1]],
                    y=[lab[2]],
                    mode="markers",
                    marker=dict(
                        size=11 if is_closest else 8,
                        color=proto_hex,
                        line=dict(
                            color="black",
                            width=3 if is_closest else 1,
                        ),
                        symbol="circle",
                    ),
                    name=str(label),
                    legendgroup=str(label),
                    showlegend=True,
                    hovertemplate=(
                        f"<b>{label}</b><br>"
                        "a*: %{x:.3f}<br>"
                        "b*: %{y:.3f}<extra></extra>"
                    ),
                )
            )

        if custom_lab is not None:
            fig.add_trace(
                go.Scatter(
                    x=[custom_lab[1]],
                    y=[custom_lab[2]],
                    mode="markers",
                    marker=dict(
                        size=10,
                        color=custom_hex,
                        symbol="diamond",
                        line=dict(color="black", width=1.8),
                    ),
                    name="Custom color",
                    showlegend=True,
                    hovertemplate=(
                        "<b>Custom color</b><br>"
                        "a*: %{x:.3f}<br>"
                        "b*: %{y:.3f}<extra></extra>"
                    ),
                )
            )

        # It shares legendgroup with the closest prototype, so if the user
        # hides that color from the legend, this highlight also disappears.
        if closest_lab is not None:
            fig.add_trace(
                go.Scatter(
                    x=[closest_lab[1]],
                    y=[closest_lab[2]],
                    mode="markers",
                    marker=dict(
                        size=14,
                        color=closest_hex,
                        symbol="circle-open",
                        line=dict(color="black", width=3.5),
                    ),
                    name=str(closest_label),
                    legendgroup=str(closest_label),
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{closest_label}</b><br>"
                        "a*: %{x:.3f}<br>"
                        "b*: %{y:.3f}<extra></extra>"
                    ),
                )
            )

        fig.update_layout(
            title=dict(
                text=f"{filename} | a*b* projection",
                x=0.5,
                font=dict(
                    size=16,
                    family="Arial, sans-serif",
                    color="#3F374C",
                ),
            ),
            dragmode="pan",
            xaxis_title="a* (green ↔ red)",
            yaxis_title="b* (blue ↔ yellow)",
            legend=dict(
                x=1.02,
                y=1.0,
                xanchor="left",
                yanchor="top",
                groupclick="togglegroup",
                title=dict(text="Colors"),
                bgcolor="rgba(255,255,255,0.94)",
                bordercolor="rgba(0,0,0,0.12)",
                borderwidth=1,
                font=dict(size=10, color="#3F374C"),
                itemsizing="constant",
            ),
            margin=dict(l=65, r=230, t=60, b=60),
            paper_bgcolor="white",
            plot_bgcolor="white",
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#3F374C",
                font=dict(color="#3F374C"),
            ),
        )

        fig.update_xaxes(
            zeroline=True,
            zerolinewidth=1,
            zerolinecolor="gray",
            gridcolor="rgba(0,0,0,0.08)",
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
        )

        fig.update_yaxes(
            zeroline=True,
            zerolinewidth=1,
            zerolinecolor="gray",
            gridcolor="rgba(0,0,0,0.08)",
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
            scaleanchor="x",
            scaleratio=1,
        )

        return fig


    @staticmethod
    def plot_color_evaluation_lc_projection(
        color_data,
        hex_color,
        custom_lab=None,
        custom_hex="#ff0000",
        closest_label=None,
        closest_lab=None,
        closest_hex="#000000",
        filename="Color evaluation",
    ):
        """
        2D L*C* projection.

        Shows lightness L* versus chroma C* for all prototypes.
        Works with or without a custom/sample color.
        The default interaction mode is pan instead of zoom.
        If custom color is available, the closest prototype is inferred when needed.
        """
        fig = go.Figure()

        color_data = color_data or {}
        custom_lab = VisualManager._safe_lab(custom_lab)
        closest_lab = VisualManager._safe_lab(closest_lab)

        # Resolve the comparison prototype from its label or LAB distance.
        if custom_lab is not None and closest_lab is None:
            if closest_label is not None:
                for label, value in color_data.items():
                    if str(label) != str(closest_label):
                        continue

                    try:
                        closest_lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        closest_hex = VisualManager._find_hex_for_lab(
                            closest_lab,
                            hex_color,
                            default=closest_hex,
                        )
                        break
                    except Exception:
                        continue

            if closest_lab is None:
                best_label = None
                best_lab = None
                best_hex = closest_hex
                best_distance = float("inf")

                for label, value in color_data.items():
                    try:
                        lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        distance = float(np.linalg.norm(custom_lab - lab))

                        if distance < best_distance:
                            best_distance = distance
                            best_label = str(label)
                            best_lab = lab
                            best_hex = VisualManager._find_hex_for_lab(
                                lab,
                                hex_color,
                                default=closest_hex,
                            )
                    except Exception:
                        continue

                if best_lab is not None:
                    closest_label = best_label
                    closest_lab = best_lab
                    closest_hex = best_hex

        has_distance_line = custom_lab is not None and closest_lab is not None

        # Distance line first, so markers remain above it.
        if has_distance_line:
            L1, C1, _h1 = VisualManager._lab_to_lch(custom_lab)
            L2, C2, _h2 = VisualManager._lab_to_lch(closest_lab)

            # Faint underlying stroke
            fig.add_trace(
                go.Scatter(
                    x=[C1, C2],
                    y=[L1, L2],
                    mode="lines",
                    line=dict(
                        color="rgba(255,255,255,0.95)",
                        width=6,
                    ),
                    showlegend=False,
                    hoverinfo="skip",
                )
            )

            # Foreground dashed stroke
            fig.add_trace(
                go.Scatter(
                    x=[C1, C2],
                    y=[L1, L2],
                    mode="lines",
                    line=dict(
                        color="rgba(35,54,79,0.95)",
                        width=2.6,
                        dash="dot",
                    ),
                    name="Custom → closest line",
                    showlegend=True,
                    hoverinfo="skip",
                )
            )

        for label, value in color_data.items():
            try:
                lab = np.asarray(value["positive_prototype"], dtype=float).reshape(-1)[:3]
                L, C, _h = VisualManager._lab_to_lch(lab)
            except Exception:
                continue

            proto_hex = VisualManager._find_hex_for_lab(
                lab,
                hex_color,
                default="#000000"
            )

            is_closest = (
                closest_label is not None
                and str(label) == str(closest_label)
            )

            fig.add_trace(
                go.Scatter(
                    x=[C],
                    y=[L],
                    mode="markers",
                    marker=dict(
                        size=11 if is_closest else 8,
                        color=proto_hex,
                        symbol="circle",
                        line=dict(
                            color="black",
                            width=3 if is_closest else 1,
                        ),
                    ),
                    name=str(label),
                    legendgroup=str(label),
                    showlegend=True,
                    hovertemplate=(
                        f"<b>{label}</b><br>"
                        "C*: %{x:.3f}<br>"
                        "L*: %{y:.3f}<extra></extra>"
                    ),
                )
            )

        if custom_lab is not None:
            L, C, _h = VisualManager._lab_to_lch(custom_lab)

            fig.add_trace(
                go.Scatter(
                    x=[C],
                    y=[L],
                    mode="markers",
                    marker=dict(
                        size=10,
                        color=custom_hex,
                        symbol="diamond",
                        line=dict(color="black", width=1.8),
                    ),
                    name="Custom color",
                    showlegend=True,
                    hovertemplate=(
                        "<b>Custom color</b><br>"
                        "C*: %{x:.3f}<br>"
                        "L*: %{y:.3f}<extra></extra>"
                    ),
                )
            )

        # Same legendgroup, so it disappears when the user hides that color.
        if closest_lab is not None:
            L, C, _h = VisualManager._lab_to_lch(closest_lab)

            fig.add_trace(
                go.Scatter(
                    x=[C],
                    y=[L],
                    mode="markers",
                    marker=dict(
                        size=14,
                        color=closest_hex,
                        symbol="circle-open",
                        line=dict(color="black", width=3.5),
                    ),
                    name=str(closest_label),
                    legendgroup=str(closest_label),
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{closest_label}</b><br>"
                        "C*: %{x:.3f}<br>"
                        "L*: %{y:.3f}<extra></extra>"
                    ),
                )
            )

        fig.update_layout(
            title=dict(
                text=f"{filename} | L*C* projection",
                x=0.5,
                font=dict(
                    size=16,
                    family="Arial, sans-serif",
                    color="#3F374C",
                ),
            ),
            dragmode="pan",
            xaxis_title="C* (Chroma)",
            yaxis_title="L* (Lightness)",
            legend=dict(
                x=1.02,
                y=1.0,
                xanchor="left",
                yanchor="top",
                groupclick="togglegroup",
                title=dict(text="Colors"),
                bgcolor="rgba(255,255,255,0.94)",
                bordercolor="rgba(0,0,0,0.12)",
                borderwidth=1,
                font=dict(size=10, color="#3F374C"),
                itemsizing="constant",
            ),
            margin=dict(l=65, r=230, t=60, b=60),
            paper_bgcolor="white",
            plot_bgcolor="white",
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#3F374C",
                font=dict(color="#3F374C"),
            ),
        )

        fig.update_xaxes(
            zeroline=True,
            zerolinewidth=1,
            zerolinecolor="gray",
            gridcolor="rgba(0,0,0,0.08)",
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
        )

        fig.update_yaxes(
            range=[0, 100],
            zeroline=True,
            zerolinewidth=1,
            zerolinecolor="gray",
            gridcolor="rgba(0,0,0,0.08)",
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
        )

        return fig


    @staticmethod
    def plot_color_evaluation_lch_polar(
        color_data,
        hex_color,
        custom_lab=None,
        custom_hex="#ff0000",
        closest_label=None,
        closest_lab=None,
        closest_hex="#000000",
        filename="Color evaluation",
    ):
        """
        Polar LCh plot.

        Angle = hue h°
        Radius = chroma C*
        Marker hover includes L*.
        Works with or without a custom/sample color.
        If custom color is available, the closest prototype is inferred when needed.
        """
        fig = go.Figure()

        color_data = color_data or {}
        custom_lab = VisualManager._safe_lab(custom_lab)
        closest_lab = VisualManager._safe_lab(closest_lab)

        # Resolve the comparison prototype from its label or LAB distance.
        if custom_lab is not None and closest_lab is None:
            if closest_label is not None:
                for label, value in color_data.items():
                    if str(label) != str(closest_label):
                        continue

                    try:
                        closest_lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        closest_hex = VisualManager._find_hex_for_lab(
                            closest_lab,
                            hex_color,
                            default=closest_hex,
                        )
                        break
                    except Exception:
                        continue

            if closest_lab is None:
                best_label = None
                best_lab = None
                best_hex = closest_hex
                best_distance = float("inf")

                for label, value in color_data.items():
                    try:
                        lab = np.asarray(
                            value["positive_prototype"],
                            dtype=float
                        ).reshape(-1)[:3]

                        distance = float(np.linalg.norm(custom_lab - lab))

                        if distance < best_distance:
                            best_distance = distance
                            best_label = str(label)
                            best_lab = lab
                            best_hex = VisualManager._find_hex_for_lab(
                                lab,
                                hex_color,
                                default=closest_hex,
                            )
                    except Exception:
                        continue

                if best_lab is not None:
                    closest_label = best_label
                    closest_lab = best_lab
                    closest_hex = best_hex

        has_distance_line = custom_lab is not None and closest_lab is not None

        # Distance line first, so markers remain above it.
        if has_distance_line:
            L1, C1, h1 = VisualManager._lab_to_lch(custom_lab)
            L2, C2, h2 = VisualManager._lab_to_lch(closest_lab)

            # Faint underlying stroke
            fig.add_trace(
                go.Scatterpolar(
                    r=[C1, C2],
                    theta=[h1, h2],
                    mode="lines",
                    line=dict(
                        color="rgba(255,255,255,0.95)",
                        width=6,
                    ),
                    showlegend=False,
                    hoverinfo="skip",
                )
            )

            # Foreground dashed stroke
            fig.add_trace(
                go.Scatterpolar(
                    r=[C1, C2],
                    theta=[h1, h2],
                    mode="lines",
                    line=dict(
                        color="rgba(35,54,79,0.95)",
                        width=2.6,
                        dash="dot",
                    ),
                    name="Custom → closest line",
                    showlegend=True,
                    hoverinfo="skip",
                )
            )

        for label, value in color_data.items():
            try:
                lab = np.asarray(value["positive_prototype"], dtype=float).reshape(-1)[:3]
                L, C, h = VisualManager._lab_to_lch(lab)
            except Exception:
                continue

            proto_hex = VisualManager._find_hex_for_lab(
                lab,
                hex_color,
                default="#000000"
            )

            is_closest = (
                closest_label is not None
                and str(label) == str(closest_label)
            )

            fig.add_trace(
                go.Scatterpolar(
                    r=[C],
                    theta=[h],
                    mode="markers",
                    marker=dict(
                        size=11 if is_closest else 8,
                        color=proto_hex,
                        symbol="circle",
                        line=dict(
                            color="black",
                            width=3 if is_closest else 1,
                        ),
                    ),
                    name=str(label),
                    legendgroup=str(label),
                    showlegend=True,
                    hovertemplate=(
                        f"<b>{label}</b><br>"
                        "h°: %{theta:.2f}<br>"
                        "C*: %{r:.3f}<br>"
                        f"L*: {L:.3f}<extra></extra>"
                    ),
                )
            )

        if custom_lab is not None:
            L, C, h = VisualManager._lab_to_lch(custom_lab)

            fig.add_trace(
                go.Scatterpolar(
                    r=[C],
                    theta=[h],
                    mode="markers",
                    marker=dict(
                        size=10,
                        color=custom_hex,
                        symbol="diamond",
                        line=dict(color="black", width=1.8),
                    ),
                    name="Custom color",
                    showlegend=True,
                    hovertemplate=(
                        "<b>Custom color</b><br>"
                        "h°: %{theta:.2f}<br>"
                        "C*: %{r:.3f}<br>"
                        f"L*: {L:.3f}<extra></extra>"
                    ),
                )
            )

        # Same legendgroup, so it disappears when the user hides that color.
        if closest_lab is not None:
            L, C, h = VisualManager._lab_to_lch(closest_lab)

            fig.add_trace(
                go.Scatterpolar(
                    r=[C],
                    theta=[h],
                    mode="markers",
                    marker=dict(
                        size=14,
                        color=closest_hex,
                        symbol="circle-open",
                        line=dict(color="black", width=3.5),
                    ),
                    name=str(closest_label),
                    legendgroup=str(closest_label),
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{closest_label}</b><br>"
                        "h°: %{theta:.2f}<br>"
                        "C*: %{r:.3f}<br>"
                        f"L*: {L:.3f}<extra></extra>"
                    ),
                )
            )

        fig.update_layout(
            title=dict(
                text=f"{filename} | LCh hue/chroma",
                x=0.5,
                font=dict(
                    size=16,
                    family="Arial, sans-serif",
                    color="#3F374C",
                ),
            ),
            dragmode="pan",
            polar=dict(
                radialaxis=dict(
                    title="C*",
                    gridcolor="rgba(0,0,0,0.08)",
                    linecolor="rgba(0,0,0,0.25)",
                ),
                angularaxis=dict(
                    direction="counterclockwise",
                    rotation=0,
                    gridcolor="rgba(0,0,0,0.08)",
                    linecolor="rgba(0,0,0,0.25)",
                ),
                bgcolor="white",
            ),
            legend=dict(
                x=1.02,
                y=1.0,
                xanchor="left",
                yanchor="top",
                groupclick="togglegroup",
                title=dict(text="Colors"),
                bgcolor="rgba(255,255,255,0.94)",
                bordercolor="rgba(0,0,0,0.12)",
                borderwidth=1,
                font=dict(size=10, color="#3F374C"),
                itemsizing="constant",
            ),
            margin=dict(l=65, r=230, t=60, b=60),
            paper_bgcolor="white",
            plot_bgcolor="white",
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#3F374C",
                font=dict(color="#3F374C"),
            ),
        )

        return fig


    @staticmethod
    def plot_color_evaluation_top7_bar(
        ranking,
        metric_name="CIEDE2000",
        title="Top 7 closest prototypes",
        threshold_settings=None,
    ):
        """
        Horizontal bar chart for the closest 7 prototypes.

        Ranking items may contain:
            - metric_value
            - delta_e

        Visual improvements:
            - Best/closest prototype highlighted.
            - Cleaner background and grid.
            - Threshold guide lines follow the active threshold settings.
            - Default interaction mode set to pan.
        """
        ranking = ranking or []
        ranking = ranking[:7]

        labels = []
        values = []

        for item in ranking:
            try:
                labels.append(str(item["label"]))
                values.append(float(VisualManager._get_ranking_metric_value(item)))
            except Exception:
                continue

        fig = go.Figure()

        if not labels or not values:
            fig.update_layout(
                title=dict(text=title, x=0.5),
                paper_bgcolor="white",
                plot_bgcolor="white",
            )
            return fig

        labels_plot = labels[::-1]
        values_plot = values[::-1]

        # Closest is the first item in the original ranking.
        # After reversing, it is the last displayed bar, visually at the top.
        colors = []

        for label in labels_plot:
            if label == labels[0]:
                colors.append("rgba(35,54,79,0.95)")      # Closest prototype
            else:
                colors.append("rgba(135,157,184,0.72)")   # Other prototypes

        fig.add_trace(
            go.Bar(
                x=values_plot,
                y=labels_plot,
                orientation="h",
                marker=dict(
                    color=colors,
                    line=dict(
                        color="rgba(35,54,79,0.45)",
                        width=1,
                    ),
                ),
                text=[
                    VisualManager._format_metric_value(v, metric_name)
                    for v in values_plot
                ],
                textposition="outside",
                cliponaxis=False,
                hovertemplate=(
                    "<b>%{y}</b><br>"
                    + str(metric_name)
                    + ": %{x:.3f}<extra></extra>"
                ),
            )
        )

        # Active threshold guide lines.
        # This is linked to threshold_settings:
        #   mode="default":
        #       preset="pt"    -> PT only
        #       preset="at"    -> AT only
        #       preset="pt_at" -> PT + AT
        #   mode="custom":
        #       custom_type="single"      -> one custom threshold
        #       custom_type="lower_upper" -> lower + upper thresholds
        def _safe_positive_float(value):
            try:
                parsed = float(value)
                if parsed > 0:
                    return parsed
            except Exception:
                pass
            return None

        def _metric_matches_threshold_settings():
            if not threshold_settings:
                return False

            active_metric = str(threshold_settings.get("metric", "")).strip()
            current_metric = str(metric_name).strip()

            # If no metric is stored in settings, allow the guide.
            if not active_metric:
                return True

            return active_metric == current_metric

        def _get_active_threshold_guides():
            if not threshold_settings or not _metric_matches_threshold_settings():
                return []

            mode = str(threshold_settings.get("mode", "default")).strip().lower()
            preset = str(threshold_settings.get("preset", "pt_at")).strip().lower()
            custom_type = str(threshold_settings.get("custom_type", "single")).strip().lower()

            guides = []

            if mode in ("default", "known"):
                if preset == "pt":
                    guides.append(
                        (0.8, "PT 0.8", "rgba(64,128,64,0.75)")
                    )

                elif preset == "at":
                    guides.append(
                        (1.8, "AT 1.8", "rgba(180,120,35,0.75)")
                    )

                else:
                    guides.extend([
                        (0.8, "PT 0.8", "rgba(64,128,64,0.75)"),
                        (1.8, "AT 1.8", "rgba(180,120,35,0.75)"),
                    ])

            elif mode == "custom":
                if custom_type == "single":
                    value = _safe_positive_float(threshold_settings.get("single"))

                    if value is not None:
                        guides.append(
                            (value, f"Threshold {value:g}", "rgba(90,90,160,0.80)")
                        )

                else:
                    lower = _safe_positive_float(threshold_settings.get("lower"))
                    upper = _safe_positive_float(threshold_settings.get("upper"))

                    if lower is not None:
                        guides.append(
                            (lower, f"Lower {lower:g}", "rgba(64,128,64,0.75)")
                        )

                    if upper is not None:
                        guides.append(
                            (upper, f"Upper {upper:g}", "rgba(180,80,65,0.75)")
                        )

            return guides

        shapes = []
        annotations = []

        active_guides = _get_active_threshold_guides()

        for x_value, label_text, color in active_guides:
            shapes.append(
                dict(
                    type="line",
                    x0=x_value,
                    x1=x_value,
                    y0=-0.5,
                    y1=len(labels_plot) - 0.5,
                    xref="x",
                    yref="y",
                    line=dict(
                        color=color,
                        width=1.7,
                        dash="dot",
                    ),
                )
            )

            annotations.append(
                dict(
                    x=x_value,
                    y=1.04,
                    xref="x",
                    yref="paper",
                    text=label_text,
                    showarrow=False,
                    font=dict(
                        size=10,
                        color=color,
                    ),
                    xanchor="center",
                )
            )

        fig.update_layout(
            title=dict(
                text=title,
                x=0.5,
                font=dict(
                    size=16,
                    family="Arial, sans-serif",
                    color="#3F374C",
                ),
            ),
            dragmode="pan",
            xaxis_title=metric_name,
            yaxis_title="Prototype",
            shapes=shapes,
            annotations=annotations,
            margin=dict(l=135, r=70, t=65, b=55),
            paper_bgcolor="white",
            plot_bgcolor="white",
            bargap=0.28,
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#3F374C",
                font=dict(color="#3F374C"),
            ),
        )

        fig.update_xaxes(
            zeroline=True,
            zerolinewidth=1,
            zerolinecolor="rgba(0,0,0,0.35)",
            gridcolor="rgba(0,0,0,0.08)",
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
        )

        fig.update_yaxes(
            gridcolor="rgba(0,0,0,0.04)",
            showline=True,
            linecolor="rgba(0,0,0,0.20)",
            mirror=True,
        )

        return fig


    @staticmethod
    def plot_color_evaluation_membership_bar(
        memberships,
        title="Membership degrees",
        top_n=10,
    ):
        """
        Horizontal bar chart for membership degrees.

        memberships is expected as:
            [(label, mu), ...]

        Visual improvements:
            - Color encodes membership strength.
            - Winner is visually emphasized.
            - Cleaner grid and fixed 0-1 scale.
            - Default interaction mode set to pan.
        """
        memberships = memberships or []
        memberships = sorted(
            memberships,
            key=lambda item: float(item[1]),
            reverse=True
        )[:top_n]

        labels = []
        values = []

        for label, mu in memberships:
            try:
                labels.append(str(label))
                values.append(float(mu))
            except Exception:
                continue

        fig = go.Figure()

        if not labels or not values:
            fig.update_layout(
                title=dict(text=title, x=0.5),
                paper_bgcolor="white",
                plot_bgcolor="white",
            )
            return fig

        labels_plot = labels[::-1]
        values_plot = values[::-1]

        def _membership_color(mu):
            if mu >= 0.75:
                return "rgba(46,125,82,0.92)"       # high
            if mu >= 0.40:
                return "rgba(58,112,165,0.86)"      # medium
            if mu >= 0.15:
                return "rgba(190,139,56,0.82)"      # low-medium
            return "rgba(160,160,160,0.70)"         # low

        colors = [_membership_color(v) for v in values_plot]

        fig.add_trace(
            go.Bar(
                x=values_plot,
                y=labels_plot,
                orientation="h",
                marker=dict(
                    color=colors,
                    line=dict(
                        color="rgba(35,54,79,0.35)",
                        width=1,
                    ),
                ),
                text=[f"{v:.4f}" for v in values_plot],
                textposition="outside",
                cliponaxis=False,
                hovertemplate="<b>%{y}</b><br>μ = %{x:.4f}<extra></extra>",
            )
        )

        shapes = [
            dict(
                type="rect",
                x0=0.0,
                x1=0.4,
                y0=-0.5,
                y1=len(labels_plot) - 0.5,
                xref="x",
                yref="y",
                fillcolor="rgba(160,160,160,0.055)",
                line=dict(width=0),
                layer="below",
            ),
            dict(
                type="rect",
                x0=0.4,
                x1=0.75,
                y0=-0.5,
                y1=len(labels_plot) - 0.5,
                xref="x",
                yref="y",
                fillcolor="rgba(58,112,165,0.045)",
                line=dict(width=0),
                layer="below",
            ),
            dict(
                type="rect",
                x0=0.75,
                x1=1.0,
                y0=-0.5,
                y1=len(labels_plot) - 0.5,
                xref="x",
                yref="y",
                fillcolor="rgba(46,125,82,0.055)",
                line=dict(width=0),
                layer="below",
            ),
        ]

        fig.update_layout(
            title=dict(
                text=title,
                x=0.5,
                font=dict(
                    size=16,
                    family="Arial, sans-serif",
                    color="#3F374C",
                ),
            ),
            dragmode="pan",
            xaxis_title="Membership degree (μ)",
            yaxis_title="Prototype",
            shapes=shapes,
            margin=dict(l=140, r=75, t=60, b=55),
            paper_bgcolor="white",
            plot_bgcolor="white",
            bargap=0.28,
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#3F374C",
                font=dict(color="#3F374C"),
            ),
        )

        fig.update_xaxes(
            range=[0, 1.05],
            tickformat=".2f",
            zeroline=True,
            zerolinewidth=1,
            zerolinecolor="rgba(0,0,0,0.35)",
            gridcolor="rgba(0,0,0,0.08)",
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
        )

        fig.update_yaxes(
            gridcolor="rgba(0,0,0,0.04)",
            showline=True,
            linecolor="rgba(0,0,0,0.20)",
            mirror=True,
        )

        return fig


    @staticmethod
    def plot_color_evaluation_component_differences(
        components,
        title="Component differences",
    ):
        """
        Bar chart for signed component differences.

        Expected keys:
            ΔL*, Δa*, Δb*, ΔC*, Δh°, ΔH*

        Visual improvements:
            - Positive/negative components are visually separated.
            - Zero baseline is emphasized.
            - Cleaner grid and better text placement.
            - Default interaction mode set to pan.
        """
        components = components or {}

        keys = ["ΔL*", "Δa*", "Δb*", "ΔC*", "Δh°", "ΔH*"]
        values = []

        for key in keys:
            try:
                values.append(float(components.get(key, 0.0)))
            except Exception:
                values.append(0.0)

        max_abs = max([abs(v) for v in values] + [1.0])
        y_padding = max_abs * 0.18

        colors = []

        for value in values:
            if value > 0:
                colors.append("rgba(190,88,64,0.88)")      # positive
            elif value < 0:
                colors.append("rgba(58,112,165,0.88)")     # negative
            else:
                colors.append("rgba(160,160,160,0.70)")    # zero

        fig = go.Figure()

        fig.add_trace(
            go.Bar(
                x=keys,
                y=values,
                marker=dict(
                    color=colors,
                    line=dict(
                        color="rgba(35,54,79,0.35)",
                        width=1,
                    ),
                ),
                text=[f"{v:+.3f}" for v in values],
                textposition=[
                    "outside" if v >= 0 else "outside"
                    for v in values
                ],
                cliponaxis=False,
                hovertemplate="<b>%{x}</b><br>Value: %{y:+.3f}<extra></extra>",
            )
        )

        fig.update_layout(
            title=dict(
                text=title,
                x=0.5,
                font=dict(
                    size=16,
                    family="Arial, sans-serif",
                    color="#3F374C",
                ),
            ),
            dragmode="pan",
            xaxis_title="Component",
            yaxis_title="Signed difference",
            margin=dict(l=70, r=45, t=60, b=60),
            paper_bgcolor="white",
            plot_bgcolor="white",
            bargap=0.34,
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#3F374C",
                font=dict(color="#3F374C"),
            ),
            shapes=[
                dict(
                    type="line",
                    x0=-0.5,
                    x1=len(keys) - 0.5,
                    y0=0,
                    y1=0,
                    xref="x",
                    yref="y",
                    line=dict(
                        color="rgba(35,54,79,0.75)",
                        width=1.8,
                    ),
                )
            ],
        )

        fig.update_xaxes(
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
            gridcolor="rgba(0,0,0,0.04)",
        )

        fig.update_yaxes(
            range=[
                min(values) - y_padding,
                max(values) + y_padding,
            ],
            zeroline=False,
            gridcolor="rgba(0,0,0,0.08)",
            showline=True,
            linecolor="rgba(0,0,0,0.25)",
            mirror=True,
        )

        return fig