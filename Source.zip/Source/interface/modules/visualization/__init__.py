"""PyFCS visualization package."""
