"""PyFCS creation package."""
