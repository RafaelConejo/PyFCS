
"""Palette-local granule actions using PyFCS' existing RGB / LAB / HEX dialog.

All edits are temporary until a new fuzzy color space is created. The class
keeps UI responsibilities small: PaletteBasedCreationManager owns the table
and category selection, while this adapter handles add / edit / remove.
"""

import tkinter as tk
from tkinter import messagebox

import numpy as np

from Source.geometry.Voronoi import Voronoi
import Source.interface.modules.UtilsTools as UtilsTools


class GranuleManager:
    """Add, edit or remove positive granules for a palette category."""

    def __init__(self, palette, category_label):
        self.palette = palette
        self.category_label = category_label

    @property
    def granules(self):
        return self.palette.colors[self.category_label]["granules"]

    def _next_label(self):
        used = self.palette._used_granule_labels()
        number = len(self.granules) + 1
        while True:
            proposal = self.palette._auto_granule_label(self.category_label, number - 1)
            if proposal not in used:
                return proposal
            number += 1

    def _validate(self, label, lab, exclude_index=None):
        label = str(label or "").strip()
        if not label or len(label) > UtilsTools.MAX_COLOR_NAME_CHARS:
            raise ValueError(f"Granule name must contain 1 to {UtilsTools.MAX_COLOR_NAME_CHARS} characters.")
        for category, data in self.palette.colors.items():
            for index, other in enumerate(data.get("granules", [])):
                if category == self.category_label and index == exclude_index:
                    continue
                if other["label"] == label:
                    raise ValueError(f"Granule label '{label}' is already in use.")
        point = np.asarray(lab, dtype=float).reshape(-1)
        if point.shape != (3,) or not np.all(np.isfinite(point)) or not UtilsTools.is_valid_lab(point):
            raise ValueError("The granule needs valid LAB coordinates.")
        for category, data in self.palette.colors.items():
            for index, other in enumerate(data.get("granules", [])):
                if category == self.category_label and index == exclude_index:
                    continue
                if np.linalg.norm(point - np.asarray(other["lab"], dtype=float)) <= Voronoi.DEFAULT_MERGE_EPS:
                    raise ValueError(
                        f"The LAB coordinates coincide with '{other['label']}' in '{category}'."
                    )
        return label, tuple(float(value) for value in point)

    def add(self):
        """Create a granule directly in the shared precise Color Picker."""
        suggested = self._next_label()

        def on_submit(name, lab, _rgb, _hex, _dialog, status_var):
            try:
                label, point = self._validate(name, lab)
                entries = [dict(item) for item in self.granules]
                entries.append({"label": label, "lab": point, "enabled": True})
                self.palette._set_category_granules(self.category_label, entries)
            except (ValueError, TypeError) as exc:
                status_var.set(str(exc))
                return False
            return True

        return self.palette.app._open_square_color_picker(
            parent=self.palette.win,
            title=f"Add granule — {self.category_label}",
            granule_name=suggested,
            submit_text="Add granule",
            on_granule_submit=on_submit,
        )

    def edit(self, index):
        """Edit label and exact LAB directly in the shared Color Picker."""
        if not 0 <= index < len(self.granules):
            return
        item = dict(self.granules[index])
        display_label = self.palette._granule_display_label(
            self.category_label, item, index)

        def on_submit(name, lab, _rgb, _hex, _dialog, status_var):
            try:
                label, point = self._validate(name, lab, exclude_index=index)
                entries = [dict(g) for g in self.granules]
                entries[index] = {
                    "label": label,
                    "lab": point,
                    "enabled": item.get("enabled", True),
                }
                self.palette._set_category_granules(self.category_label, entries)
            except (ValueError, TypeError) as exc:
                status_var.set(str(exc))
                return False
            return True

        return self.palette.app._open_square_color_picker(
            parent=self.palette.win,
            title=f"Edit granule — {self.category_label}",
            granule_name=display_label,
            initial_lab=item["lab"],
            submit_text="Save changes",
            on_granule_submit=on_submit,
        )

    def rename(self, index, requested):
        """Rename an existing site in place; return the name displayed in Data."""
        if not 0 <= index < len(self.granules):
            raise ValueError("Granule no longer exists.")
        current = self.granules[index]
        shown = self.palette._granule_display_label(self.category_label, current, index)
        requested = str(requested or "").strip()
        if not requested:
            raise ValueError("Granule name cannot be empty.")
        if requested == shown:
            return shown
        label, _point = self._validate(requested, current["lab"], exclude_index=index)
        current["label"] = label
        return label

    def remove(self, index):
        if not 0 <= index < len(self.granules):
            return
        if len(self.granules) <= 1:
            self.palette.app.custom_warning(
                "Cannot Remove Granule",
                "Every category must contain at least one granule.",
                parent=self.palette.win,
            )
            return
        granule = self.granules[index]
        if not messagebox.askyesno(
            "Remove Granule",
            f"Remove '{granule['label']}' from '{self.category_label}'?\n"
            "This only changes the temporary palette.",
            parent=self.palette.win,
        ):
            return
        entries = [dict(g) for i, g in enumerate(self.granules) if i != index]
        try:
            self.palette._set_category_granules(self.category_label, entries)
        except ValueError as exc:
            self.palette.app.custom_warning(
                "Cannot Remove Granule", str(exc), parent=self.palette.win)
