"""PyFCS image package."""
