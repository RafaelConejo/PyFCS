"""PyFCS evaluation package."""
