"""PyFCS interface package."""
